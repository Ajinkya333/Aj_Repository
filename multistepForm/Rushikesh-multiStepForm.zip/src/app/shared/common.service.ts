import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Product } from '../model/product';

@Injectable({
  providedIn: 'root'
})
export class CommonService {
 
url:string=" http://localhost:3000/Product/";
  constructor(private http:HttpClient) { }

  saveProduct(pro:Product):Observable<Product>
  {
    if(pro.id>0)
    {
      return this.http.put<Product>(this.url+pro.id,pro);
    }
    else
    {
      console.log("in service of saveProduct"+pro.pname);
    console.log("in service of saveProduct"+ this.url);
      return this.http.post<Product>(this.url,pro);
    }
  }

  getAllProduct():Observable<Product[]>
  {
    return this.http.get<Product[]>(this.url);
  }

  getproduct(id:number):Observable<Product>
  {
    return this.http.get<Product>(this.url+id);
  }

  deleteProduct(id: number) {
    return this.http.delete(this.url+id);
  }
}
