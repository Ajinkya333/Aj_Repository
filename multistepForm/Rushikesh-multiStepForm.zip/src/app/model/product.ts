export class Product {
    id:number;
    pname:string;
    pprice:number;
    pimg:string;
}
