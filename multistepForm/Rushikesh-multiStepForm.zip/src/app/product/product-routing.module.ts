import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ProductDetailsComponent } from './product-details/product-details.component';
import { ProductListComponent } from './product-list/product-list.component';
import { ProductComponent } from './product/product.component';
import { UpdateProductComponent } from './update-product/update-product.component';

const routes: Routes = [
  {
    path:'', component:ProductComponent,
    children:[
      {
        path:'product-list',component:ProductListComponent,
        children:[
          {
            path:'product-details/:id', component:ProductDetailsComponent
          },
          {
            path:'update', component:UpdateProductComponent
          }
        ]
      }
    ]

}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ProductRoutingModule { }
