import { Component, OnInit } from '@angular/core';
import { Product } from 'src/app/model/product';
import { CommonService } from 'src/app/shared/common.service';
import { Location } from '@angular/common';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {

  constructor(private cs:CommonService ,private location:Location) { }
prolist:Product[];
  ngOnInit(): void {
    this.cs.getAllProduct().subscribe(data=>{this.prolist=data});
  }

  deleteProduct(id:number)
  {
    this.cs.deleteProduct(id).subscribe();
    window.location.reload();
  }
}
