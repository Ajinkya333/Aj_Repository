import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CommonService } from 'src/app/shared/common.service';

@Component({
  selector: 'app-update-product',
  templateUrl: './update-product.component.html',
  styleUrls: ['./update-product.component.css']
})
export class UpdateProductComponent implements OnInit {
updateForm:FormGroup;
  constructor(private fb:FormBuilder, private cs:CommonService, private location:Location) { }

  ngOnInit(): void {
    this.updateForm=this.fb.group(
      {
        id:[],
        pname:['',[Validators.required,Validators.minLength(4),Validators.pattern('[a-zA-Z]+$')]],
        pprice:[''],
        pimg:[''],
        
      }
    )
    this.editData();
  }
  editData()
  {
    let proObj:any=this.location.getState();
    console.log("getState()"+proObj.id);
    if(proObj.id!=0)
    {
      this.updateForm.get("id").setValue(proObj.id);
      this.updateForm.get('pname').setValue(proObj.pname);
      this.updateForm.get('pprice').setValue(proObj.pprice);
      this.updateForm.get('pimg').setValue(proObj.pimg);
    }
  }

  goBack()
  {
    this.location.back();
  }

  onSubmit()
  {
    this.cs.saveProduct(this.updateForm.value).subscribe();
    this.location.back();
    window.location.reload();
  }




}
