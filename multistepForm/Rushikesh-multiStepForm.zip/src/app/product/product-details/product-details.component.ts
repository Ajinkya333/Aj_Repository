import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Product } from 'src/app/model/product';
import { CommonService } from 'src/app/shared/common.service';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent implements OnInit {

  constructor(private routes:ActivatedRoute , private cs:CommonService, private location:Location) { }
proObj:Product={
  id: 0,
  pname: '',
  pprice: 0,
  pimg: ''
}
  ngOnInit(): void {
    //by using observable way
    this.routes.paramMap.subscribe(param1=>{
      this.cs.getproduct(parseInt(param1.get('id'))).subscribe(data=>{
        this.proObj=data;
      })
    })
  }
  getback()
  {
    this.location.back();
  }
}
