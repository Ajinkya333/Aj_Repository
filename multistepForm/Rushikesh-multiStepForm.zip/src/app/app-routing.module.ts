import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { headroutes } from './header/header-routing.module';
import { HeaderComponent } from './header/header/header.component';
import { LoginComponent } from './login/login.component';
import { RegistrationComponent } from './registration/registration.component';

const routes: Routes = [
  {
    path:'', redirectTo:'login', pathMatch:'full'
  },
  {
    path:'login',component:LoginComponent
  },
  {
    path:'login/register', component:RegistrationComponent
  },
  {
    path:'login/header', component:HeaderComponent ,children:headroutes
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
