import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CommonService } from '../shared/common.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
loginForm:FormGroup;
  constructor(private fb:FormBuilder, private rt:Router,private cs:CommonService) { }

  ngOnInit(): void {
    this.createLoginForm();
  }

  createLoginForm(){
    this.loginForm=this.fb.group({
      username:['',[Validators.required]],
      password:['',[Validators.required]]
    })
  }

  onLoginSubmit()
  {
    if(this.loginForm.valid && this.loginForm.get('username').value=="ADMIN" && this.loginForm.get('password').value=="ADMIN" )
    {
      this.rt.navigate(['login/header']);
    }
  }

}
