import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutUsComponent } from '../about-us/about-us.component';
import { DashboardComponent } from '../dashboard/dashboard.component';

export const headroutes: Routes = [
  {
    path:'dashboard', component:DashboardComponent
  },
  {
    path:'about-us', component:AboutUsComponent
  },
  {
    path:'product',
    loadChildren:()=>import("src/app/product/product.module").then(module=>module.ProductModule)
  }

];

@NgModule({
  imports: [RouterModule.forChild(headroutes)],
  exports: [RouterModule]
})
export class HeaderRoutingModule { }
